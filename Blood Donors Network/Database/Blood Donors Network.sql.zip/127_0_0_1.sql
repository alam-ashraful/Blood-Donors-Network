-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2018 at 07:20 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood donors network`
--
CREATE DATABASE IF NOT EXISTS `blood donors network` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `blood donors network`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(10) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `EmailID` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PhoneNumber` varchar(50) NOT NULL,
  `BirthDate` date NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `BloodGroup` varchar(10) NOT NULL,
  `Division` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `Area` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `FirstName`, `LastName`, `EmailID`, `Password`, `PhoneNumber`, `BirthDate`, `Gender`, `BloodGroup`, `Division`, `District`, `Area`) VALUES
(8, 'admin', 'admin', 'admin@ewu.edu', '$2y$10$Vu1DUJeePm2CXAXHmK3rN.AHKDmu1yOoCeaj8lSdtWuO87bj/zVfO', '017xxxxxxxxxx', '2018-01-01', 'male', 'A+', 'Dhaka', 'Dhaka', 'Badda');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(10) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `EmailID` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PhoneNumber` varchar(50) NOT NULL,
  `BirthDate` date NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `BloodGroup` varchar(10) NOT NULL,
  `Division` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `Area` varchar(50) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `FirstName`, `LastName`, `EmailID`, `Password`, `PhoneNumber`, `BirthDate`, `Gender`, `BloodGroup`, `Division`, `District`, `Area`, `Status`) VALUES
(2, 'Jame', 'Ahmed', 'jameahmed125@yahoo.com', '$2y$10$Vu1DUJeePm2CXAXHmK3rN.AHKDmu1yOoCeaj8lSdtWuO87bj/zVfO', '01521434331', '1994-07-08', 'Male', 'O-', 'Rajshahi', 'Sirajganj', 'Amlapara', 'Yes'),
(5, 'Farhan', 'Labib', 'farhanlabib72@gmail.com', '$2y$10$TfzXjMaVsIScihsKuY6nJuSNvkQK7ZKNkip3x9I3sKAn91eB9kKKW', '01740127697', '1995-01-01', 'Male', 'B+', 'Rajshahi', 'Sirajganj', 'BiralaKuthi', 'Yes'),
(6, 'Sadia', 'Afroz', 'sadia@aiub.edu', '$2y$10$u2gvAsRtNQyVNHqq3gqgZ.Vmo/88MlV53i20EwmeUvBboXVbNfClO', '017XXXXXXXXX', '1996-01-01', 'Female', 'O+', 'Dhaka', 'Dhaka', 'Airport Road', 'Yes'),
(7, 'Raisul', 'Islam', 'raisul@nbmch.com', '$2y$10$pcNy5sXRDZGCNYem7UiCh.fWUtcY3aOKmubYxxSxCM74suexV8xSy', '017XXXXXXXXX', '1994-01-01', 'Male', 'AB+', 'Rajshahi', 'Sirajganj', 'Bankpara', 'Yes'),
(8, 'Zahangir', 'H. Shakil', 'shakil710@gmail.com', '$2y$10$vl.dmzsAO5cnSjRwlwFIC.vhCt1qLku7Z1Puf42z5LXRcOAZjaJHW', '01737899937', '1995-12-07', 'Male', 'O+', 'Dhaka', 'Dhaka', 'Badda', 'Yes'),
(11, 'Maisha', 'Haque', 'maisha@aiub.edu', '$2y$10$jcURlsOPNaC006w5Kut.COad8ASfDJ6r8x1FBX7/lF8gPk5QU9Ngy', '017XXXXXXXXX', '1995-01-01', 'Female', 'B-', 'Dhaka', 'Dhaka', 'Dhaka', 'Yes'),
(12, 'Ridita', 'Islam', 'ridita@aiub.edu', '$2y$10$.PXXbb1CCsq7dlR24SqckOZL8yKQ.yjAfOT5L9ELYiD.l/VdRdCza', '017XXXXXXXXX', '1995-01-01', 'Female', 'AB-', 'Dhaka', 'Dhaka', 'Dhaka', 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `EmailID` (`EmailID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `EmailID` (`EmailID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
